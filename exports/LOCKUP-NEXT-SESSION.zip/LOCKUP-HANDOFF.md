# Lockup handoff — finish the last three things only

Owner: Jeff. Written 2026-10-03 after he approved the pose and rejected every later attempt that fixed one detail by undoing another.

Do not redesign this lockup. The pose, expressions, fur, skin, scale, and proportions are accepted. Change only the three items in section 2. If a change would alter anything else, do not make it.

## 1. Start here. Do not start over.

| File | What it is |
|---|---|
| [deliverables/POSE-LOCKED__hat-reads-DOC__do-not-unwind.jpg](/workspace/deliverables/POSE-LOCKED__hat-reads-DOC__do-not-unwind.jpg) | The accepted 3D pose. Hat patch currently reads **DOC** only. Bib is good enough. This is the base. |
| [PART-1_UPLOAD/01_TARGET_cutout_cream-on-navy_4619x3296.png](/workspace/PART-1_UPLOAD/01_TARGET_cutout_cream-on-navy_4619x3296.png) | Hat-patch **geometry**. The tan patch sits on the cap, above the goggles, and does not cover them. Two lines, same letter size: DOC / TUMBLENUT. |
| [PART-1_UPLOAD/03_TARGET_silhouette-filled_4619x3296.png](/workspace/PART-1_UPLOAD/03_TARGET_silhouette-filled_4619x3296.png) | Outer silhouette. Clip the final art to this. Do not let paint stick out past it. |
| [ref/footer-lockup-3d.png](/workspace/ref/footer-lockup-3d.png) | Live site footer, also at `https://tumblenut.com/brand/cast/lockup-3d.png`. Authority for **toe count and toe shape**, and for **how a die sits on a jar** (curved, printed on the glass, under the lid). Not the pose. Do not copy this composition. |
| [ref/smokehouse-almond.png](/workspace/ref/smokehouse-almond.png) | The die to bake onto **this** jar. Words and layout come from this file, not from whatever flavor is on the footer jar. |
| [PART-1_UPLOAD/12_REEL_crop_CECIL-legs-claws_4.55s.png](/workspace/PART-1_UPLOAD/12_REEL_crop_CECIL-legs-claws_4.55s.png) | Cecil claw color and scale texture. Pale claws, three toes. |
| [PART-1_UPLOAD/14_JAR-LABEL-ONLY_from-old-lockup_use-for-label-layout-and-words-only.png](/workspace/PART-1_UPLOAD/14_JAR-LABEL-ONLY_from-old-lockup_use-for-label-layout-and-words-only.png) | Older label crop. Use only if the die file is unclear. Do not take faces, pose, or color from it. |

The current master on the preview is this same DOC-only pose, cut to the cream silhouette, on transparent and on navy `#0C2340`. Long side 6400. Leave the bib alone.

## 2. The only remaining work

1. **Doc's feet.** Exactly 3 toes on each foot, matching the footer lockup: rounded toes, a small dark claw on each. He currently reads as 4 on at least one paw. Remove the extra toe. Do not add toes.
2. **Cecil's left front foot.** Exactly 3 toes, including the smaller inner toe, with claws. That inner toe is missing. Do not change his other foot unless it is also not 3.
3. **Hat patch.** Same patch shape and place as the cream lockup. It must not grow and must not cover the goggles. Two lines, **the same letter size**: `DOC` then `TUMBLENUT`. The letters are part of the patch, not a sticker laid on top of the DOC that is already there. Clear the old DOC before painting the two lines, or the old word shows through.
4. **Jar.** Bake [ref/smokehouse-almond.png](/workspace/ref/smokehouse-almond.png) onto the jar the way the footer lockup's label is baked on: curved with the glass, under the gold lid, readable as the SKU. Not a flat rectangle, not type set in a box on top of the glass. Lid, hand, and jar shape stay.

## 3. How to change a region without unwinding the pose

- The base image is frozen. Copy it. Paint only inside a mask.
- Hat mask: the tan patch already on the cap in the locked pose. Nothing below it. After the edit, the goggle pixels must be identical to the locked pose (measured difference about 0).
- Foot mask: only the toes being corrected. If the whole picture moves by the same amount as the feet, the edit failed. Do not ship it.
- Jar mask: the existing label area on the glass only.
- Bib mask: do not touch it.
- Anything outside the mask is copied unchanged from the locked pose, including the other fix once that one has passed.

## 4. What already failed. Do not do these again.

- Pasting or scaling a letter block onto the hat. Jeff saw it as a sticker on top of the patch.
- Drawing `DOC TUMBLENUT` over the existing large `DOC`. Both showed at once.
- Letting the hat patch grow down over the goggles so the second line would fit.
- An elliptical crop on the bib. It cut a circle through DOC and the peanut. The bib is now acceptable. Leave it.
- Telling an image model to "fix the toes" and shipping the result when the feet had barely changed. Those runs moved the feet by about as much as the rest of the picture (a difference around 5 to 9). That is not a new toe.
- Pasting `smokehouse-almond.png` on as a flat sticker, or onto the cap mesh, the arm, or the overalls.
- Regenerating the whole lockup to fix one detail. That is how the pose got unwound.

## 5. Check before showing Jeff

Show him nothing until all of these are true on the file you would actually deliver:

- Goggle pixels match the locked pose.
- The hat patch is the original shape. It reads DOC on line 1 and TUMBLENUT on line 2, same size, and the old DOC is gone.
- The bib still matches the locked pose.
- Doc: 3 toes per foot. Cecil's left front foot: 3 toes, inner one included. Compare crops to [ref/footer-lockup-3d.png](/workspace/ref/footer-lockup-3d.png).
- The jar label is the smokehouse die, curved on the glass. If the label area is still the dark glass with no die artwork, it is not done. Do not describe a label that is not in the pixels.
- Transparent background. No magenta fringe. Silhouette clipped to `03_TARGET_silhouette-filled`.
- Crops to look at: hat, bib, jar, Doc's feet, Cecil's left front foot.

## 6. Out of scope

Do not start the flat embroidery version, tent panels, or any other part of the original brief. This handoff is only the four items in section 2, on the locked pose.
